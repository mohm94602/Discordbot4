# سياق مشروع Discord Bot — للذكاء الاصطناعي

أنت مساعد متخصص في تعديل وتطوير هذا البوت. اقرأ هذا الملف كاملاً قبل تنفيذ أي طلب.

---

## نظرة عامة

هذا بوت Discord مكتوب بـ **Node.js / discord.js v14**، يعمل بذكاء اصطناعي (Gemini API).
البوت يفهم الأوامر بالعربية الطبيعية، يحوّلها لـ JSON، ثم ينفّذها على السيرفر.

**هيكل الملفات:**
```
discord-bot/
├── index.js              ← نقطة البداية
├── package.json
├── data/
│   ├── memory.json       ← سياق المحادثات (يُحفظ على القرص)
│   └── audit-channels.json ← قنوات السجل لكل سيرفر
└── src/
    ├── config.js         ← الإعدادات ومتغيرات البيئة
    ├── client.js         ← إنشاء Discord client وتسجيل الأحداث
    ├── handler.js        ← معالجة الرسائل الواردة (المنطق الرئيسي)
    ├── ai.js             ← البرومت + التواصل مع Gemini API
    ├── commands.js       ← تنفيذ الأوامر الفعلية على Discord
    ├── memory.js         ← حفظ واسترجاع سياق المحادثة
    ├── audit.js          ← إرسال سجل الأوامر لقناة معينة
    ├── auditStore.js     ← حفظ/قراءة قناة السجل لكل سيرفر
    └── setupServer.js    ← إنشاء هيكل افتراضي للسيرفر
```

---

## تدفق العمل (Flow)

```
رسالة المستخدم
      ↓
handler.js: هل المستخدم مصرّح؟ هل الرسالة تبدأ بـ ! أو mention؟
      ↓
ai.js: يبني البرومت مع سياق السيرفر والتاريخ، يرسل لـ Gemini
      ↓
Gemini يرجع JSON: { actions: [...], response: "..." }
      ↓
commands.js: ينفّذ كل action واحد بواحد
      ↓
handler.js: يجمع النتائج ويرسلها كـ Embed للمستخدم
      ↓
memory.js: يحفظ الرسالة والرد في السياق
      ↓
audit.js: يسجّل الأمر في قناة السجل (إن كانت محددة)
```

---

## src/config.js — الإعدادات

متغيرات البيئة المطلوبة في `.env`:
```
DISCORD_TOKEN        ← توكن البوت
GEMINI_API_KEY_1     ← مفتاح Gemini الأول (يدعم حتى 10 مفاتيح)
GEMINI_API_KEY_2     ← اختياري
BOT_NAME             ← اسم البوت (افتراضي: DevBot)
ADMIN_ID             ← ID المستخدم الوحيد المصرّح (اختياري)
CLIENT_ID            ← client ID للبوت
```

**المتغيرات الثابتة في الكود:**
```js
config.aiModel       = 'gemini-2.5-flash'
config.memoryTtlMs   = 72 ساعة
config.memoryMaxItems = 12 رسالة
config.askOnlyUserIds = ['...'] // مستخدمون يقدرون يسألون فقط بدون تنفيذ أوامر
```

**الدوال المصدّرة:**
- `getCurrentKey()` / `rotateKey()` — إدارة دوران مفاتيح API
- `setKeyIndex(n)` / `getKeyIndex()` / `getKeysCount()`
- `assertConfig()` — يتحقق من وجود التوكن والمفاتيح

---

## src/handler.js — قلب البوت

**يستجيب فقط لـ:**
- رسائل تبدأ بـ `!`
- رسائل تذكر (mention) البوت
- **لا** يستجيب للبوتات أو DMs أو interactions

**التحقق من الصلاحية (`isAuthorized`):**
- المستخدمون في `askOnlyUserIds` → يقدرون يسألون فقط
- إذا `adminId` موجود → فقط صاحب الـ ID
- وإلا → أي عضو عنده صلاحية Administrator

**الحماية من التكرار:**
- `activeReplies` (Set) — يمنع معالجة نفس المستخدم مرتين بالتوازي
- `userCooldowns` (Map) — كولداون 3 ثواني بين كل طلب

**أوامر مدمجة مباشرة في handler (بدون AI):**
- `key1` إلى `key10` → تبديل مفتاح Gemini يدوياً
- `keys` → عرض المفتاح النشط حالياً

**بناء الـ Embed:**
- العنوان دائماً: `🤖 {botName}`
- لون ثابت: `#5865F2`
- يضيف حقل "النتائج" فقط إذا كانت هناك أوامر فعلية نُفّذت

---

## src/ai.js — الذكاء الاصطناعي

### buildSystemPrompt(ctx)

يبني البرومت الكامل المرسل لـ Gemini في كل طلب. يحتوي على:
- معلومات السيرفر الديناميكية (اسم، عدد أعضاء، قائمة القنوات بـ IDs، قائمة الرولات بـ IDs)
- وصف دور البوت الثلاثي (إداري، AI عام، تفاعلي)
- قائمة كاملة بكل الأوامر المتاحة مع بارامترات كل أمر
- قواعد الرد (متى تستخدم reply، متى تستخدم response، عدم التكرار)
- ملاحظات خاصة بالموسيقى والـ embed

### صيغة الرد من Gemini (دائماً JSON):
```json
{
  "actions": [
    { "type": "اسم_الأمر", "param1": "...", "param2": "..." }
  ],
  "response": "نص قصير للمستخدم أو فارغ"
}
```

### callAI()
- يحوّل التاريخ لصيغة Gemini (user/model)
- يجرّب كل المفاتيح المتاحة عند خطأ الكوتا
- `maxOutputTokens: 2048`، `temperature: 0.4`، `responseMimeType: 'application/json'`

---

## src/commands.js — تنفيذ الأوامر

كل أمر هو دالة `async` تأخذ `(action, ctx)` حيث:
- `action` = الكائن القادم من Gemini (بارامترات الأمر)
- `ctx` = `{ guild, message }` — الـ Discord context

### قائمة كاملة بالأوامر:

#### إدارة القنوات
| الأمر | البارامترات |
|-------|-------------|
| `createChannel` | `{ name, channelType: "text"\|"voice"\|"category", categoryId? }` |
| `deleteChannel` | `{ channelId }` |
| `renameChannel` | `{ channelId, newName }` |
| `setChannelTopic` | `{ channelId, topic }` |
| `lockChannel` | `{ channelId }` |
| `unlockChannel` | `{ channelId }` |
| `clearMessages` | `{ channelId, amount }` — حد أقصى 100 |

#### إدارة الأعضاء
| الأمر | البارامترات |
|-------|-------------|
| `createRole` | `{ name, color? }` |
| `deleteRole` | `{ roleId }` |
| `assignRole` | `{ userId, roleId }` |
| `removeRole` | `{ userId, roleId }` |
| `kickMember` | `{ userId, reason? }` |
| `banMember` | `{ userId, reason?, days? }` |
| `unbanMember` | `{ userId }` |

#### إعلانات وتفاعل
| الأمر | البارامترات |
|-------|-------------|
| `sendAnnouncement` | `{ channelId, title?, message, color? }` |
| `sendEmbed` | `{ channelId, title, description, color?, footer?, fields?: [{name,value,inline?}] }` |
| `sendPoll` | `{ channelId, question, options: string[] }` — بحد أقصى 9، يضيف إيموجي تلقائياً ويتفاعل |
| `sendWelcome` | `{ channelId, userId, message? }` — embed مع افتار العضو |

#### الموسيقى (يحتاج باكجات إضافية)
| الأمر | البارامترات | ملاحظة |
|-------|-------------|--------|
| `playMusic` | `{ voiceChannelId, query }` | query = رابط YouTube مباشر |
| `stopMusic` | `{}` | يفرّغ القائمة ويغادر |
| `skipMusic` | `{}` | يوقف الأغنية الحالية |
| `pauseMusic` | `{}` | |
| `resumeMusic` | `{}` | |
| `setVolume` | `{ volume }` — 0 إلى 100 | |
| `showQueue` | `{}` | يرسل embed بقائمة الأغاني |

**الباكجات المطلوبة للموسيقى:**
```
@discordjs/voice, ytdl-core, @discordjs/opus, ffmpeg-static, sodium-native
```
حالة الموسيقى محفوظة في `musicState` (Map) داخل `commands.js` — مستقلة لكل سيرفر.

#### مسابقات وسحوبات
| الأمر | البارامترات |
|-------|-------------|
| `sendQuiz` | `{ channelId, question, answer, hint? }` — ينتظر 60 ثانية ويعلن الفائز تلقائياً |
| `sendGiveaway` | `{ channelId, prize, duration, winnersCount? }` — يتفاعل بـ 🎉 ويختار فائزين عشوائياً |

#### معلومات
| الأمر | البارامترات |
|-------|-------------|
| `getAvatar` | `{ userId }` — embed مع صورة عالية الجودة |
| `getUserInfo` | `{ userId }` — رولات، تاريخ انضمام، تاريخ إنشاء الحساب |
| `getServerStats` | `{}` — إحصائيات السيرفر كاملة |
| `showHelp` | `{}` — embed شامل بكل المميزات وأمثلة |

#### النظام
| الأمر | البارامترات |
|-------|-------------|
| `reply` | `{ message }` — للردود النصية المعلوماتية فقط |
| `setupServer` | `{}` — ينشئ هيكل قنوات ورولات افتراضي |
| `setAuditChannel` | `{ channelId }` |
| `clearAuditChannel` | `{}` |
| `clearHistory` | `{ userId? }` |

**إضافة أمر جديد:**
1. أضف الدالة في `handlers` داخل `commands.js`
2. أضف الأمر وبارامتراته في البرومت داخل `ai.js` (في قسم "الأوامر المتاحة")
3. إذا أردت قاعدة خاصة، أضفها في قسم "قواعد الرد"

---

## src/memory.js — الذاكرة

- يخزّن سياق المحادثة في Map (RAM) + ملف JSON (قرص)
- المفتاح: `{guildId}:{userId}`
- حد أقصى: آخر 12 رسالة، تنتهي صلاحيتها بعد 72 ساعة
- **الدوال:** `rememberUserMessage()`, `rememberAssistantReply()`, `getHistory()`, `clearHistory()`

---

## src/audit.js + auditStore.js — السجل

- كل أمر يُنفَّذ يُرسَل كـ embed لقناة السجل (إن كانت محددة)
- السجل يحتوي: المستخدم، القناة، الطلب، الرد، نتائج الأوامر
- `auditStore.js` يحفظ ID قناة السجل لكل سيرفر في `data/audit-channels.json`

---

## src/setupServer.js — الإعداد الافتراضي

عند تنفيذ `setupServer`، ينشئ:

**الفئات والقنوات:**
- 📋 INFORMATION: announcements, rules, welcome
- 💻 DEVELOPMENT: general-dev, bug-reports, ideas, releases
- 🌐 COMMUNITY: general, off-topic
- 🔊 VOICE: General, Dev Meeting

**الرولات:**
- 👑 Admin (أحمر), 🛠️ Developer (أخضر), 👥 Member (أزرق)

لا يحذف الموجود — يتحقق أولاً ويضيف الناقص فقط.

---

## نقاط مهمة للتعديل

1. **تغيير النموذج:** في `config.js` غيّر `aiModel`
2. **تغيير لغة البوت:** في `ai.js` في `buildSystemPrompt` عدّل سطر اللغة
3. **إضافة صلاحيات:** في `handler.js` في دالة `isAuthorized`
4. **تغيير شكل الـ Embed:** في `handler.js` في `buildResponseEmbed`
5. **تغيير كولداون:** في `handler.js` غيّر `COOLDOWN_MS`
6. **تغيير حد الذاكرة:** في `config.js` غيّر `memoryMaxItems` و `memoryTtlMs`
7. **دعم Spotify:** يحتاج استبدال `ytdl-core` بـ `play-dl` الذي يدعم Spotify/SoundCloud
8. **البحث باسم الأغنية:** أضف `youtube-search-without-api-key` وعدّل handler الـ `playMusic`

---

## القيود الحالية

- الموسيقى تقبل روابط YouTube مباشرة فقط (البحث بالاسم غير مفعّل)
- لا يعمل في DMs
- `clearMessages` لا يحذف رسائل أقدم من 14 يوم (قيد Discord)
- السحب (`sendGiveaway`) يعتمد على التفاعل بـ 🎉 — لو البوت ريستارت أثناء السحب ينقطع
